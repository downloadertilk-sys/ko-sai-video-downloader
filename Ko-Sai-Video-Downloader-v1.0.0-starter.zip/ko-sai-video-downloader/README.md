# Ko Sai Video Downloader

Android-first Capacitor starter project. Public GitHub repository name: `ko-sai-video-downloader`.

## Current starter features
- Burmese-first home screen
- Dark / light theme toggle
- YouTube URL parsing and privacy-enhanced official YouTube embed player
- Media file picker UI
- Local download-history UI (localStorage)

## Important implementation status
This is the **initial UI scaffold**, not a finished downloader. MP3/MP4 conversion and native file saving are not implemented yet. Add a properly licensed local media-processing engine in a later step and only process files the user owns or is authorized to download/convert. Do not bypass YouTube restrictions or download protected streams.

## Run locally
```bash
npm install
npm run dev
```

## Add Android platform
```bash
npm install
npx cap add android
npm run build
npx cap sync android
```
Open Android Studio with:
```bash
npx cap open android
```

## GitHub
Create a **Public** repository named `ko-sai-video-downloader`, upload the project files, then add Android build workflow in the next project step. Never commit signing keys or passwords.
