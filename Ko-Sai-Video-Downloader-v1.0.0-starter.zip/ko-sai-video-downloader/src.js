import './style.css';
const $=s=>document.querySelector(s);
const pages=[...document.querySelectorAll('.page')], tabs=[...document.querySelectorAll('.tab')];
function go(id){pages.forEach(p=>p.classList.toggle('active',p.id===id));tabs.forEach(t=>t.classList.toggle('active',t.dataset.page===id));}
document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.page)));
$('#theme').onclick=()=>{document.body.classList.toggle('light');$('#theme').textContent=document.body.classList.contains('light')?'☾':'☼';};
function embed(url){let id='';try{const u=new URL(url);if(u.hostname.includes('youtu.be'))id=u.pathname.slice(1);else id=u.searchParams.get('v')||u.pathname.split('/').filter(Boolean).pop();}catch{}if(!/^[\w-]{11}$/.test(id)){alert('YouTube URL မှန်ကန်စွာ ထည့်ပါ။');return;}$('#player').innerHTML=`<iframe src="https://www.youtube-nocookie.com/embed/${id}" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>`;}
$('#playYt').onclick=()=>embed($('#yturl').value.trim());
$('#openUrl').onclick=()=>{const v=$('#url').value.trim();if(v.includes('youtu')){$('#yturl').value=v;go('youtube');embed(v);}else{alert('ဤနေရာတွင် YouTube URL ကို ထည့်နိုင်ပါသည်။');}};
let selected=null, history=JSON.parse(localStorage.getItem('ks-history')||'[]');
$('#mediaFile').onchange=e=>{selected=e.target.files[0];$('#fileInfo').textContent=selected?`${selected.name} · ${(selected.size/1048576).toFixed(2)} MB`:'ဖိုင်မရွေးရသေးပါ။';};
function saveHistory(kind){if(!selected){alert('အရင်ဆုံး Media ဖိုင်ရွေးပါ။');return;}history.unshift({name:selected.name,kind,time:new Date().toLocaleString()});localStorage.setItem('ks-history',JSON.stringify(history));renderHistory();alert(`${kind} လုပ်ဆောင်ချက်ကို နောက်အဆင့်တွင် Media Engine ချိတ်ဆက်ပြီး အသုံးပြုနိုင်ပါမည်။`);}
$('#mp3').onclick=()=>saveHistory('MP3');$('#mp4').onclick=()=>saveHistory('MP4');
function renderHistory(){$('#historyList').innerHTML=history.length?history.map(x=>`<div class="historyitem"><b>${escapeHtml(x.name)}</b><small>${x.kind} · ${x.time}</small></div>`).join(''):'မှတ်တမ်းမရှိသေးပါ။';}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
$('#clearHistory').onclick=()=>{history=[];localStorage.removeItem('ks-history');renderHistory();};renderHistory();
